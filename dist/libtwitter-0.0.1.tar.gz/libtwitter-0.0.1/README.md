LibTwitter
==========

Biblioteca para pesquisa e processamento de tweets.

Para utilizar as funções da bibblioteca é necessário obter as keys da API do Twitter


## Instalação

`pip install libTwitter`

## Funções
- Pesquisar Tweets 
- Publicar Tweets
- Gerar Wordclouds

